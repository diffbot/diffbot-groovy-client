package com.diffbot

import groovyx.net.http.ContentType
import groovyx.net.http.HTTPBuilder
import groovyx.net.http.Method

/**
 * <p>The class is used to analyse a shopping or e-commerce product page and returns information on the product.</p>
 */
class DiffbotProduct {

    private static final String DIFFBOT_URL = 'http://api.diffbot.com'
    private static final String DIFFBOT_PATH = '/v2/product'

    /**
     * <p>Analyzes web page with given URL and returns product details in the products array.
     * Currently extracted data will only be returned from a single product.
     * In the future the API will return information from multiple products, if multiple items are available on the same page.</p>
     *
     * Parameter <code>options</code> isn't required. Available options:<br/>
     * - <code>fields</code> - used to control which fields are returned by the API.<br/>
     * - <code>timeout</code> - set a value in milliseconds to terminate the response. By default there is no timeout.<br/>
     * - <code>callback</code> - used for jsonp requests. Needed for cross-domain ajax.<br/>
     *
     * <p>Use the <code>fields</code> query parameter to limit or expand which fields are returned in the JSON response.
     * For product-specific content your desired fields should be contained within the 'products' parentheses:</p>
     *
     * <p><code>http://api.diffbot.com/v2/product...&fields=products(offerPrice,sku)</code></p>
     *
     * <table>
     *   <thead>
     *   <tr>
     *     <th>Field</th>
     *     <th>Description</th>
     *   </tr>
     *   </thead>
     *   <tbody>
     *   <tr>
     *     <td valign="top"><code>*</code></td>
     *     <td>Returns all fields available.</td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>url</code></td>
     *     <td>URL submitted. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>resolved_url</code></td>
     *     <td>Returned if the resolving URL is different from the submitted URL (e.g., link shortening services). <em>Returned
     *       by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>meta</code></td>
     *     <td>Returns the full contents of page <code>meta</code> tags, including sub-arrays for <a target="_new"
     *                                                                                               href="http://ogp.me/">OpenGraph</a>
     *       tags, <a target="_new" href="https://dev.twitter.com/docs/cards/markup-reference">Twitter Card</a> metadata, <a
     *           target="_new" hef="http://www.schema.org">schema.org</a> microdata, and -- if available -- <a target="_new"
     *                                                                                                         href="http://www.oembed.com">oEmbed</a>
     *       metadata. <em>Returned with <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>querystring</code></td>
     *     <td>Returns the key/value pairs of the URL querystring, if present. Items without a value will be returned as
     *       "true." <em>Returned with <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>links</code></td>
     *     <td>Returns all links (anchor tag <code>href</code> values) found on the page. <em>Returned with <code>fields</code>.</em>
     *     </td>
     *   </tr>
     *      *
     *   <tr>
     *     <td valign="top"><code>breadcrumb</code></td>
     *     <td>If available, an array of link URLs and link text from page breadcrumbs. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top" colspan="2"><strong>For each item in the <code>products</code> array:</strong></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>title</code></td>
     *     <td>Name of the product. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>description</code></td>
     *     <td>Description, if available, of the product. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>brand</code></td>
     *     <td><em>Experimental</em> Brand, if available, of the product. <em>Returned with <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>media</code></td>
     *     <td>
     *       Array of media items (images or videos) of the product. <em>Returned by default.</em><br/>
     *       Sub-fields:<br/>
     *        - <code>type</code> - Type of media identified (image or video).
     *        - <code>link</code> - Direct (fully resolved) link to image or video content.
     *        - <code>height</code> - Image height, in pixels.
     *        - <code>width</code> - Image width, in pixels.
     *        - <code>caption</code> - Diffbot-determined best caption for the image.
     *        - <code>primary</code> - <em>Only images.</em> Returns "True" if image is identified as primary in terms of size or positioning.
     *        - <code>xpath</code> - Full document Xpath to the media item.
     *     </td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>offerPrice</code></td>
     *     <td>Identified offer or actual/'final' price of the product. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>regularPrice</code></td>
     *     <td>Regular or original price of the product, if available. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>saveAmount</code></td>
     *     <td>Discount or amount saved, if available. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>shippingAmount</code></td>
     *     <td>Shipping price, if available. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>productId</code></td>
     *     <td>A Diffbot-determined unique product ID. If <code>upc</code>, <code>isbn</code>, <code>mpn</code> or
     *       <code>sku</code> are identified on the page, <code>productId</code> will select from these values in the above
     *       order. Otherwise Diffbot will attempt to derive the best unique value for the product. <em>Returned by
     *         default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>upc</code></td>
     *     <td>Universal Product Code (UPC/EAN), if available. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>prefixCode</code></td>
     *     <td>GTIN prefix code, typically the country of origin as identified by UPC/ISBN. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>productOrigin</code></td>
     *     <td>If available, the two-character ISO country code where the product was produced. <em>Returned by default.</em>
     *     </td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>isbn</code></td>
     *     <td>International Standard Book Number (ISBN), if available. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>sku</code></td>
     *     <td>Stock Keeping Unit -- store/vendor inventory number -- if available. <em>Returned with <code>fields</code>.</em>
     *     </td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>mpn</code></td>
     *     <td>Manufacturer's Product Number, if available. <em>Returned with <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td colspan="2"><strong>The following fields are in an early beta stage:</strong></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>availability</code></td>
     *     <td>Item's availability, either <code>true</code> or <code>false</code>. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>brand</code></td>
     *     <td>The item brand, if identified. <em>Returned with <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>quantityPrices</code></td>
     *     <td>If a product page includes discounts for quantity purchases, <code>quantityPrices</code> will return an array of
     *       quantity and price values. <em>Returned with <code>fields</code>.</em></td>
     *   </tr>
     *   </tbody>
     * </table>
     * <br/>
     *
     * <p>Returned value is an instance of java.util.HashMap, e.g.:</p>
     * <code>def result = DiffbotArticle.analyze(token, url)<br/>
     * assert result instanceof java.util.HashMap</code><br/>
     *
     * <p>It's possible to cast returned value to net.sf.json.JSONObject, e.g.:</p>
     * <code>net.sf.json.JSONObject result = DiffbotArticle.analyze(token, url)<br/>
     * assert result instanceof net.sf.json.JSONObject</code>
     *
     * @param token developer token.
     * @param url article URL to process(URL encoded).
     * @param options optional arguments, isn't required.
     * @return result of analysis as java.util.HashMap.
     */
    public static Object analyze(String token, String url, Map options = null) {

        Map query = [:]
        query.token = token
        query.url = url
        if (options?.fields) query.fields = options.fields
        if (options?.timeout) query.timeout = options.timeout
        if (options?.callback) query.callback = options.callback

        HTTPBuilder http = new HTTPBuilder(DIFFBOT_URL)
        return http.request(Method.GET, ContentType.JSON) {
            uri.path = DIFFBOT_PATH
            uri.query = query

            response.success = { resp, data ->
                return data
            }

            response.failure = { resp, data ->
                return data
            }
        }
    }

}