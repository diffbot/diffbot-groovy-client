package com.diffbot

import groovyx.net.http.ContentType
import groovyx.net.http.HTTPBuilder
import groovyx.net.http.Method

/**
 * <p>The class is used to analyse a web page and returns its primary image(s).</p>
 */
class DiffbotImage {

    private static final String DIFFBOT_URL = 'http://api.diffbot.com'
    private static final String DIFFBOT_PATH = '/v2/image'

    /**
     * <p>Analyzes web page with given URL and returns basic info about the page submitted,
     * and its primary image(s) in the images array.</p>
     *
     * Parameter <code>options</code> isn't required. Available options:<br/>
     * - <code>fields</code> - used to control which fields are returned by the API.<br/>
     * - <code>timeout</code> - set a value in milliseconds to terminate the response. By default there is no timeout.<br/>
     * - <code>callback</code> - used for jsonp requests. Needed for cross-domain ajax.<br/>
     *
     * <p>Use the <code>fields</code> query parameter to limit or expand which fields are returned in the JSON response.
     * To control the fields returned for images, your desired fields should be contained within the 'images' parentheses:</p>
     *
     * <p><code>http://api.diffbot.com/v2/image...&fields=images(mime,pixelWidth)</code></p>
     *
     * <table>
     *   <thead>
     *   <tr>
     *     <th>Field</th>
     *     <th>Description</th>
     *   </tr>
     *   </thead>
     *   <tbody>
     *   <tr>
     *     <td valign="top"><code>*</code></td>
     *     <td>Returns all fields available.</td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>title</code></td>
     *     <td>Title of the submitted page. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>nextPage</code></td>
     *     <td>Link to next page (if within a gallery or paginated list of images). <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>albumUrl</code></td>
     *     <td>Link to containing album (if image is within an album). <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>url</code></td>
     *     <td>URL submitted. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>resolved_url</code></td>
     *     <td>Returned if the resolving URL is different from the submitted URL (e.g., link shortening services).</td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>meta</code></td>
     *     <td>Returns the full contents of page <code>meta</code> tags, including sub-arrays for <a target="_new"
     *                                                                                               href="http://ogp.me/">OpenGraph</a>
     *       tags, <a target="_new" href="https://dev.twitter.com/docs/cards/markup-reference">Twitter Card</a> metadata, <a
     *           target="_new" hef="http://www.schema.org">schema.org</a> microdata, and -- if available -- <a target="_new"
     *                                                                                                         href="http://www.oembed.com">oEmbed</a>
     *       metadata. <em>Returned with <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>querystring</code></td>
     *     <td>Returns the key/value pairs of the URL querystring, if present. Items without a value will be returned as
     *       "true." <em>Returned with <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>links</code></td>
     *     <td>Returns all links (anchor tag <code>href</code> values) found on the page. <em>Returned with <code>fields</code>.</em>
     *     </td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>images</code></td>
     *     <td valign="top">An array of image(s) contained on the page.</td>
     *   </tr>
     *   <tr>
     *     <td colspan="2"><strong>For each item in the <code>images</code> array:</strong></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>url</code></td>
     *     <td>Direct link to image file. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>anchorUrl</code></td>
     *     <td>If the image is wrapped by an anchor <code>a</code> tag, the anchor location as defined by the <code>href</code>
     *       attribute. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>mime</code></td>
     *     <td>MIME type, if available, as specified by "Content-Type" of the image. <em>Returned with
     *       <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>caption</code></td>
     *     <td>The best caption for this image. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>attrAlt</code></td>
     *     <td>Contents of the <code>alt</code> attribute, if available within the HTML <code>IMG</code> tag. <em>Returned with
     *       <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>attrTitle</code></td>
     *     <td>Contents of the <code>title</code> attribute, if available within the HTML <code>IMG</code> tag. <em>Returned
     *       with <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>date</code></td>
     *     <td>Date of image upload or creation if available in page metadata. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>size</code></td>
     *     <td>Size in bytes of image file. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>pixelHeight</code></td>
     *     <td>Actual height, in pixels, of image file. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>pixelWidth</code></td>
     *     <td>Actual width, in pixels, of image file. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>displayHeight</code></td>
     *     <td>Height of image as rendered on page, if different from actual (pixel) height. <em>Returned with
     *       <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>displayWidth</code></td>
     *     <td>Width of image as rendered on page, if different from actual (pixel) width. <em>Returned with
     *       <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>meta</code></td>
     *     <td>Comma-separated list of image-embedded metadata (e.g., <a target="_blank"
     *                                                                   href="http://en.wikipedia.org/wiki/Exchangeable_image_file_format">EXIF</a>,
     *       <a target="_blank" href="http://en.wikipedia.org/wiki/Extensible_Metadata_Platform">XMP</a>, <a target="_blank"
     *                                                                                                       href="http://en.wikipedia.org/wiki/ICC_profile">ICC
     *         Profile</a>), if available within the image file. <em>Returned with <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>faces</code></td>
     *     <td>The x, y, height, width of coordinates of human faces. Null, if no faces were found.<em>Returned with <code>fields</code>.</em>
     *     </td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>ocr</code></td>
     *     <td>If text is identified within the image, we will attempt to recognize the text string. <em>Returned with <code>fields</code>.</em>
     *     </td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>colors</code></td>
     *     <td>Returns an array of hex values of the dominant colors within the image. <em>Returned with
     *       <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>xpath</code></td>
     *     <td>XPath expression identifying the node containing the image. <em>Returned by default.</em></td>
     *   </tr>
     *   </tbody>
     * </table>
     * <br/>
     *
     * <p>Returned value is an instance of java.util.HashMap, e.g.:</p>
     * <code>def result = DiffbotArticle.analyze(token, url)<br/>
     * assert result instanceof java.util.HashMap</code><br/>
     *
     * <p>It's possible to cast returned value to net.sf.json.JSONObject, e.g.:</p>
     * <code>net.sf.json.JSONObject result = DiffbotArticle.analyze(token, url)<br/>
     * assert result instanceof net.sf.json.JSONObject</code>
     *
     * @param token developer token.
     * @param url article URL to process(URL encoded).
     * @param options optional arguments, isn't required.
     * @return result of analysis as java.util.HashMap.
     */
    public static Object analyze(String token, String url, Map options = null) {

        Map query = [:]
        query.token = token
        query.url = url
        if (options?.fields) query.fields = options.fields
        if (options?.timeout) query.timeout = options.timeout
        if (options?.callback) query.callback = options.callback

        HTTPBuilder http = new HTTPBuilder(DIFFBOT_URL)
        return http.request(Method.GET, ContentType.JSON) {
            uri.path = DIFFBOT_PATH
            uri.query = query

            response.success = { resp, data ->
                return data
            }

            response.failure = { resp, data ->
                return data
            }
        }
    }

}