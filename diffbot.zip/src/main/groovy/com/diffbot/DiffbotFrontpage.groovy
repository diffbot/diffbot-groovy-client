package com.diffbot

import groovyx.net.http.ContentType
import groovyx.net.http.HTTPBuilder
import groovyx.net.http.Method
import groovyx.net.http.URIBuilder

/**
 * <p>The class is used to analyse a multifaceted 'homepage'.
 * The class contains static methods that returns result of page analysis.</p>
 */
public class DiffbotFrontpage {

    private static final String DIFFBOT_URL = 'http://www.diffbot.com'
    private static final String DIFFBOT_PATH = '/api/frontpage'

    /**
     * <p>Analyzes web page with given URL and returns computer vision extraction of web page.</p>
     *
     * Parameter <code>options</code> isn't required. Available options:<br/>
     * - <code>timeout</code> - set a value in milliseconds to terminate the response. By default 5000 is used.<br/>
     * - <code>format</code> - format of the response output: 'xml' (is used if not specified) or 'json'<br/>
     * - <code>all</code> - used to return all content from page, including navigation and similar links
     * that the Diffbot visual processing engine considers less important / non-core.<br/>
     *
     * <p>JSON as result:</p>
     * By default class methods returns an instance of java.util.HashMap, e.g.:<br/>
     * <code>def result = DiffbotFrontpage.analyze(token, url, [format: 'json'])<br/>
     * assert result instanceof java.util.HashMap</code><br/>
     * <br/>
     * It's possible to cast returned class to net.sf.json.JSONObject, e.g.:<br/>
     * <code>net.sf.json.JSONObject result = DiffbotFrontpage.analyze(token, url, [format: 'json'])<br/>
     * assert result instanceof net.sf.json.JSONObject</code>
     * <br/>
     * <br/>
     * <p>DML as result:</p>
     * <code>def result = DiffbotFrontpage.analyze(token, url) // it is not required to specify [format: 'xml']<br/>
     * assert result instanceof java.lang.String<br/>
     * // use groovy.util.XmlSlurper to parse XML<br/>
     * def rootNode = new XmlSlurper().parseText(result)</code>
     *
     * <p>DML (Diffbot Markup Language) is an XML format.
     * A DML consists of a single info section and a list of items.</p>
     *
     * <table>
     *   <thead>
     *   <tr>
     *     <th>Info field</th>
     *     <th>Type</th>
     *     <th>Description</th>
     *   </tr>
     *   </thead>
     *   <tbody>
     *   <tr>
     *     <td><code>id</code></td>
     *     <td>long</td>
     *     <td>DMLID of the URL</td>
     *   </tr>
     *   <tr>
     *     <td><code>title</code></td>
     *     <td>string</td>
     *     <td>Extracted title of the page</td>
     *   </tr>
     *   <tr>
     *     <td><code>sourceURL</code></td>
     *     <td>url</td>
     *     <td>the URL this was extracted from</td>
     *   </tr>
     *   <tr>
     *     <td><code>icon</code></td>
     *     <td>url</td>
     *     <td>A link to a small icon/favicon representing the page</td>
     *   </tr>
     *   <tr>
     *     <td><code>numItems</code></td>
     *     <td>int</td>
     *     <td>The number of items in this DML document</td>
     *   </tr>
     *   </tbody>
     * </table>
     *
     * <p>Some of the fields found in Items</p>
     *
     * <table>
     *   <thead>
     *   <tr>
     *     <th>Item field</th>
     *     <th>Type</th>
     *     <th>Description</th>
     *   </tr>
     *   </thead>
     *   <tbody>
     *   <tr>
     *     <td valign="top"><code>id</code></td>
     *     <td valign="top">long</td>
     *     <td>Unique hashcode/id of item</td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>title</code></td>
     *     <td valign="top">string</td>
     *     <td>Title of item</td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>description</code></td>
     *     <td valign="top">string</td>
     *     <td>innerHTML content of item</td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>xroot</code></td>
     *     <td valign="top">xpath</td>
     *     <td>XPATH of where item was found on the page</td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>pubDate</code></td>
     *     <td valign="top">timestamp</td>
     *     <td>Timestamp when item was detected on page</td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>link</code></td>
     *     <td valign="top">URL</td>
     *     <td>Extracted permalink (if applicable) of item</td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>type</code></td>
     *     <td valign="top">{IMAGE,LINK,STORY,CHUNK}</td>
     *     <td>Extracted type of the item, whether the item represents an image, permalink, story (image+summary), or html
     *       chunk.
     *     </td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>img</code></td>
     *     <td valign="top">URL</td>
     *     <td>Extracted image from item</td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>textSummary</code></td>
     *     <td valign="top">string</td>
     *     <td>A plain-text summary of the item</td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>sp</code></td>
     *     <td valign="top">double&lt;-[0,1]</td>
     *     <td>Spam score - the probability that the item is spam/ad</td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>sr</code></td>
     *     <td valign="top">double&lt;-[1,5]</td>
     *     <td>Static rank - the quality score of the item on a 1 to 5 scale</td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>fresh</code></td>
     *     <td valign="top">double&lt;-[0,1]</td>
     *     <td>Fresh score - the percentage of the item that has changed compared to the previous crawl</td>
     *   </tr>
     *   </tbody>
     * </table>
     *
     * @param token developer token.
     * @param url article URL to process(URL encoded).
     * @param options optional arguments, isn't required.
     * @return result of analysis as XML java.lang.String or java.util.HashMap.
     */
    public static Object analyze(String token, String url, Map options = null) {

        Map query = [:]
        query.token = token
        query.url = url
        if (options?.timeout) query.timeout = options.timeout
        if (options?.format) query.format = options.format
        if (options?.all) query.all = options.all

        // to support 'xml' (default) or 'json' as result
        ContentType contentType = (query.format == 'json') ? ContentType.JSON : ContentType.TEXT

        HTTPBuilder http = new HTTPBuilder(DIFFBOT_URL)
        return http.request(Method.GET, contentType) {
            uri.path = DIFFBOT_PATH
            uri.query = query

            response.success = { resp, data ->
                return (data instanceof InputStreamReader) ? data.getText() : data
            }

            response.failure = { resp, data ->
                return (data instanceof InputStreamReader) ? data.getText() : data
            }
        }
    }

    /**
     * <p>Analyzes web page by given markup and returns computer vision extraction of the markup.
     * It's used in case the page is not publicly available (e.g., behind a firewall)</p>
     *
     * <p>Parameter <code>url</code> is required in the endpoint because
     * it's used to resolve any relative links contained in the markup.</p>
     *
     * <p>Parameter <code>options</code> is described in details here {@link #analyze(String, String, Map)}.</p>
     *
     * <p>Returned value is described in details here {@link #analyze(String, String, Map)}.</p>
     *
     * @param token developer token.
     * @param url article URL to process(URL encoded).
     * @param markup content of the article to be analysed.
     * @param options optional arguments, isn't required.
     * @return result of analysis as XML java.lang.String or java.util.HashMap.
     */
    public static Object analyze(String token, String url, String markup, Map options = null) {

        Map params = [:]
        params.token = token
        params.url = url
        if (options?.timeout) params.timeout = options.timeout
        if (options?.format) params.format = options.format
        if (options?.all) params.all = options.all

        String path = new URIBuilder(DIFFBOT_URL)
                .setPath(DIFFBOT_PATH)
                .setQuery(params)
                .toString()

        // to support 'xml' (default) or 'json' as result
        ContentType contentType = (params.format == 'json') ? ContentType.JSON : ContentType.TEXT

        HTTPBuilder http = new HTTPBuilder(path)
        return http.request(Method.POST, contentType) {
            body = markup

            response.success = { resp, data ->
                return (data instanceof InputStreamReader) ? data.getText() : data
            }

            response.failure = { resp, data ->
                return (data instanceof InputStreamReader) ? data.getText() : data
            }
        }
    }

}