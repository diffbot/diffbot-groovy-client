package com.diffbot

import groovyx.net.http.ContentType
import groovyx.net.http.HTTPBuilder
import groovyx.net.http.Method
import groovyx.net.http.URIBuilder

/**
 * <p>The class is used to analyse news article, blog post and similar text-heavy web pages.
 * The class contains static methods that returns result of page analysis.</p>
 */
public class DiffbotArticle {

    private static final String DIFFBOT_URL = 'http://api.diffbot.com'
    private static final String DIFFBOT_PATH = '/v2/article'

    /**
     * <p>Analyzes web page with given URL and returns computer vision extraction of the web page.</p>
     *
     * Parameter <code>options</code> isn't required. Available options:<br/>
     * - <code>fields</code> - used to control which fields are returned by the API.<br/>
     * - <code>timeout</code> - set a value in milliseconds to terminate the response. By default there is no timeout.<br/>
     * - <code>callback</code> - used for jsonp requests. Needed for cross-domain ajax.<br/>
     *
     * <p>Use the <code>fields</code> option to limit or expand which fields are returned in the JSON response.
     * For nested arrays, use parentheses to retrieve specific fields, or <code>*</code> to return all sub-fields.</p>
     *
     * <p><code>http://api.diffbot.com/v2/article...&fields=meta,querystring,images(*)</code></p>
     *
     * <table>
     *   <thead>
     *   <tr>
     *     <th>Field</th>
     *     <th>Description</th>
     *   </tr>
     *   </thead>
     *   <tbody>
     *   <tr>
     *     <td valign="top"><code>*</code></td>
     *     <td>Returns all fields available, including experimental fields.</td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>url</code></td>
     *     <td>URL submitted. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>resolved_url</code></td>
     *     <td>Returned if the resolving URL is different from the submitted URL (e.g., link shortening services). <em>Returned
     *       by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>icon</code></td>
     *     <td>Page favicon. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>meta</code></td>
     *     <td>Returns the full contents of page <code>meta</code> tags, including sub-arrays for <a target="_new"
     *                                                                                               href="http://ogp.me/">OpenGraph</a>
     *       tags, <a target="_new" href="https://dev.twitter.com/docs/cards/markup-reference">Twitter Card</a> metadata, <a
     *           target="_new" hef="http://www.schema.org">schema.org</a> microdata, and -- if available -- <a target="_new"
     *                                                                                                         href="http://www.oembed.com">oEmbed</a>
     *       metadata. <em>Returned with <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>querystring</code></td>
     *     <td>Returns the key/value pairs of the URL querystring, if present. Items without a value will be returned as
     *       "true." <em>Returned with <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>links</code></td>
     *     <td>Returns all links (anchor tag <code>href</code> values) found on the page. <em>Returned with <code>fields</code>.</em>
     *     </td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>type</code></td>
     *     <td>Type of page -- always <code>article</code>. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>title</code></td>
     *     <td>Title of extracted article. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>text</code></td>
     *     <td>Plain-text of the extracted article. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>html</code></td>
     *     <td>HTML of the extracted article. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>numPages</code></td>
     *     <td>Number of pages automatically concatenated to form the <code>text</code> or <code>html</code> response (By
     *       default, Diffbot will automatically concatenate multiple-page articles.)
     *     </td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>date</code></td>
     *     <td>Article date, normalized in most cases to GMT. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>author</code></td>
     *     <td>Article author. <em>Returned by default.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>tags</code></td>
     *     <td>Array of tags, automatically generated by Diffbot natural-language-processing. <em>Returned with
     *       <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>humanLanguage</code></td>
     *     <td>Returns the (spoken/human) language of the submitted URL, using two-letter <a target="_blank"
     *                                                                                       href="http://en.wikipedia.org/wiki/List_of_ISO_639-1_codes">ISO
     *       639-1 nomenclature</a>. <em>Returned with <code>fields</code>.</em></td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>images</code></td>
     *     <td>
     *         Array of images, if present within the article body. <em>Returned by default.</em><br/>
     *         Sub-fields:<br/>
     *          - <code>url</code> - Direct (fully resolved) link to image.<br/>
     *          - <code>pixelHeight</code> - Image height, in pixels.<br/>
     *          - <code>pixelWidth</code> - Image width, in pixels.<br/>
     *          - <code>caption</code> - Diffbot-determined best caption for the image, if detected.<br/>
     *          - <code>primary</code> - Returns "true" if image is identified as primary based on visual analysis of the page.
     *     </td>
     *   </tr>
     *   <tr>
     *     <td valign="top"><code>videos</code></td>
     *     <td>
     *         Array of videos, if present within the article body. <em>Returned by default.</em><br/>
     *         Sub-fields:<br/>
     *          - <code>url</code> - Direct (fully resolved) link to the video content.<br/>
     *          - <code>pixelHeight</code> - Video height, in pixels, if accessible.<br/>
     *          - <code>pixelWidth</code> - Video width, in pixels, if accessible.<br/>
     *          - <code>primary</code> - Returns "true" if the video is identified as primary based on visual analysis of the page.
     *     </td>
     *   </tr>
     *   </tbody>
     * </table>
     * <br/>
     *
     * <p>Returned value is an instance of java.util.HashMap, e.g.:</p>
     * <code>def result = DiffbotArticle.analyze(token, url)<br/>
     * assert result instanceof java.util.HashMap</code><br/>
     *
     * <p>It's possible to cast returned value to net.sf.json.JSONObject, e.g.:</p>
     * <code>net.sf.json.JSONObject result = DiffbotArticle.analyze(token, url)<br/>
     * assert result instanceof net.sf.json.JSONObject</code>
     *
     * @param token developer token.
     * @param url article URL to process(URL encoded).
     * @param options optional arguments, isn't required.
     * @return result of analysis as java.util.HashMap.
     */
    public static Object analyze(String token, String url, Map options = null) {

        Map query = [:]
        query.token = token
        query.url = url
        if (options?.fields) query.fields = options.fields
        if (options?.timeout) query.timeout = options.timeout
        if (options?.callback) query.callback = options.callback

        HTTPBuilder http = new HTTPBuilder(DIFFBOT_URL)
        return http.request(Method.GET, ContentType.JSON) {
            uri.path = DIFFBOT_PATH
            uri.query = query

            response.success = { resp, data ->
                return data
            }

            response.failure = { resp, data ->
                return data
            }
        }
    }

    /**
     * <p>Analyzes web page by given markup and returns computer vision extraction of the markup.
     * It's used in case the page is not publicly available (e.g., behind a firewall)</p>
     *
     * <p>Parameter <code>url</code> is required in the endpoint because
     * it's used to resolve any relative links contained in the markup.</p>
     *
     * <p>Parameter <code>options</code> is described in details here {@link #analyze(String, String, Map)}.</p>
     *
     * <p>Returned value is an instance of java.util.HashMap, e.g.:</p>
     * <code>def result = DiffbotArticle.analyze(token, url)<br/>
     * assert result instanceof java.util.HashMap</code><br/>
     *
     * <p>It's possible to cast returned value to net.sf.json.JSONObject, e.g.:</p>
     * <code>net.sf.json.JSONObject result = DiffbotArticle.analyze(token, url)<br/>
     * assert result instanceof net.sf.json.JSONObject</code>
     *
     * @param token developer token.
     * @param url article URL(URL encoded).
     * @param markup content of the article to be analysed.
     * @param options optional arguments, isn't required.
     * @return result of analysis as java.util.HashMap.
     */
    public static Object analyze(String token, String url, String markup, Map options = null) {

        Map params = [:]
        params.token = token
        params.url = url
        if (options?.fields) params.fields = options.fields
        if (options?.timeout) params.timeout = options.timeout
        if (options?.callback) params.callback = options.callback

        String path = new URIBuilder(DIFFBOT_URL)
                .setPath(DIFFBOT_PATH)
                .setQuery(params)
                .toString()

        HTTPBuilder http = new HTTPBuilder(path)
        return http.request(Method.POST, ContentType.JSON) {
            body = markup

            response.success = { resp, data ->
                return data
            }

            response.failure = { resp, data ->
                return data
            }
        }
    }

}